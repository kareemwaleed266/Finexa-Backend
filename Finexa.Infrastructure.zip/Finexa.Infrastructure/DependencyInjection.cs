﻿namespace Finexa.Infrastructure
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddInfrastructureServices(this IServiceCollection services, IConfiguration configuration)
        {
            //// 🧩 Infrastructure Services
            //services.AddScoped<IEmailService, EmailService>();
            //services.AddScoped<ICurrencyConverter, CurrencyConverter>();


            services.AddDbContext<FinexaDbContext>(options =>
            {
                options
                .UseLazyLoadingProxies()
                .UseSqlServer(configuration.GetConnectionString("DefaultConnection"),
                    sqlOptions =>
                    {
                        sqlOptions.MigrationsAssembly(typeof(FinexaDbContext).Assembly.FullName);
                    });
            });

            services.AddScoped(typeof(IGenericRepository<,>), typeof(GenericRepository<,>));
            services.AddScoped<IFinexaContextInitializer, FinexaContextInitializer>();
            services.AddScoped<IUnitOfWork, UnitOfWork>();

            return services;
        }
    }
}
