﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Finexa.Domain.Entities.Financial;
using Finexa.Infrastructure.Persistence.Data.Configurations.BaseConfig;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Finexa.Infrastructure.Persistence.Data.Configurations.TransactionConfig
{
    public class TransactionConfig : BaseEntityConfig<Transaction>
    {
        public override void Configure(EntityTypeBuilder<Transaction> builder)
        {
            builder.Property(t => t.Amount)
                           .HasColumnType("decimal(18,2)")
                           .IsRequired();
            
            builder.Property(t => t.Type).HasConversion<int>();

            builder.HasOne(t => t.AppUser)
              .WithMany(u => u.Transactions)
              .HasForeignKey(t => t.AppUserId)
              .OnDelete(DeleteBehavior.Cascade);

            builder.HasOne(t => t.PaymentMethod)
              .WithMany()
              .HasForeignKey(t => t.PaymentMethodId)
              .OnDelete(DeleteBehavior.Restrict);

            builder.HasOne(t => t.Category)
              .WithMany()
              .HasForeignKey(t => t.CategoryId)
              .OnDelete(DeleteBehavior.Restrict);

            builder.HasIndex(t => t.AppUserId);
            builder.HasIndex(t => t.PaymentMethodId);
            builder.HasIndex(t => t.Date);
        }
    }
}
