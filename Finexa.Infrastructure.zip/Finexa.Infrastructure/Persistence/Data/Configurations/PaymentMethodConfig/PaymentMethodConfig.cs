﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Finexa.Domain.Entities.Financial;
using Finexa.Infrastructure.Persistence.Data.Configurations.BaseConfig;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Finexa.Infrastructure.Persistence.Data.Configurations.PaymentMethodConfig
{
    public class PaymentMethodConfig : BaseEntityConfig<PaymentMethod>
    {
        public override void Configure(EntityTypeBuilder<PaymentMethod> builder)
        {
            builder.Property(p => p.PassCode).HasMaxLength(6);
            builder.Property(p => p.PhoneNumber).HasMaxLength(13);
            builder.Property(p => p.IsPrimary).HasDefaultValue(false);
            builder.Property(p => p.PaymentMethodType).HasConversion<int>();

            builder.HasOne(p => p.AppUser)
                   .WithMany(u => u.PaymentMethods)
                   .HasForeignKey(p => p.AppUserId)
                   .OnDelete(DeleteBehavior.Cascade);

            builder.HasIndex(p => new { p.AppUserId, p.IsPrimary });
        }
    }
}
