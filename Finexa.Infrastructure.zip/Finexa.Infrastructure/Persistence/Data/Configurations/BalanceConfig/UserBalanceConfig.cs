﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Finexa.Domain.Entities.Financial;
using Finexa.Infrastructure.Persistence.Data.Configurations.BaseConfig;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Finexa.Infrastructure.Persistence.Data.Configurations.BalanceConfig
{
    public class UserBalanceConfig : BaseEntityConfig<UserBalance>
    {
        public override void Configure(EntityTypeBuilder<UserBalance> builder)
        {
            builder.Property(u => u.TotalIncome).HasColumnType("decimal(18,2)");
            builder.Property(u => u.TotalExpense).HasColumnType("decimal(18,2)");
            builder.Property(u => u.TotalSaving).HasColumnType("decimal(18,2)");
            builder.Property(u => u.TotalBalance).HasColumnType("decimal(18,2)");

            builder.HasOne(u => u.AppUser)
                   .WithMany()
                   .HasForeignKey(u => u.AppUserId)
                   .OnDelete(DeleteBehavior.Cascade);

            builder.HasOne(u => u.PaymentMethod)
                   .WithMany()
                   .HasForeignKey(u => u.PaymentMethodId)
                   .OnDelete(DeleteBehavior.Restrict);

            builder.HasIndex(u => new { u.AppUserId, u.PaymentMethodId });
        }
    }
}
