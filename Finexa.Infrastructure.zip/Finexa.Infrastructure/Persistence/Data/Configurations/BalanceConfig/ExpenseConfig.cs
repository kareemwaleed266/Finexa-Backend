﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Finexa.Domain.Entities.Financial;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using Finexa.Infrastructure.Persistence.Data.Configurations.BaseConfig;

namespace Finexa.Infrastructure.Persistence.Data.Configurations.BalanceConfig
{
    public class ExpenseConfig : BaseEntityConfig<Expense>
    {
        public override void Configure(EntityTypeBuilder<Expense> builder)
        {
            builder.Property(t => t.Balance)
               .HasColumnType("decimal(18,2)")
               .IsRequired();

        }
    }
}
