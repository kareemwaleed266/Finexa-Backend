﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Finexa.Domain.Entities.Financial;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using Finexa.Infrastructure.Persistence.Data.Configurations.BaseConfig;

namespace Finexa.Infrastructure.Persistence.Data.Configurations.BalanceConfig
{
    public class UserFinancialSummaryConfig : BaseEntityConfig<UserFinancialSummary>
    {
        public override void Configure(EntityTypeBuilder<UserFinancialSummary> builder)
        {
            builder.HasKey(u => u.Id);

            builder.Property(u => u.TotalBalance).HasColumnType("decimal(18,2)");
            builder.Property(u => u.TotalIncome).HasColumnType("decimal(18,2)");
            builder.Property(u => u.TotalExpense).HasColumnType("decimal(18,2)");
            builder.Property(u => u.TotalSavings).HasColumnType("decimal(18,2)");

            builder.HasOne(u => u.AppUser)
                   .WithMany()
                   .HasForeignKey(u => u.AppUserId)
                   .OnDelete(DeleteBehavior.Cascade);

            builder.HasIndex(u => u.AppUserId);
        }
    }

}
