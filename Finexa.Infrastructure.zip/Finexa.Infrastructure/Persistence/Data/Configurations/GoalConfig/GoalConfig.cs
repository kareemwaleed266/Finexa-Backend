﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Finexa.Domain.Entities.Financial;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using Finexa.Infrastructure.Persistence.Data.Configurations.BaseConfig;

namespace Finexa.Infrastructure.Persistence.Data.Configurations.GoalConfig
{
    public class GoalConfig : BaseEntityConfig<Goal>
    {
        public override void Configure(EntityTypeBuilder<Goal> builder)
        {
            builder.Property(t => t.CurrentAmount)
               .HasColumnType("decimal(18,2)")
               .IsRequired();
            
            builder.Property(t => t.TargetAmount)
               .HasColumnType("decimal(18,2)")
               .IsRequired();

            builder.Property(g => g.Status).HasConversion<int>();

        }
    }
}
