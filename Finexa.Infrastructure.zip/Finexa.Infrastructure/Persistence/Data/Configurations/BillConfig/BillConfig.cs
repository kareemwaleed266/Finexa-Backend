﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Finexa.Domain.Common.Entities;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using Finexa.Domain.Entities.Financial;
using Finexa.Infrastructure.Persistence.Data.Configurations.BaseConfig;

namespace Finexa.Infrastructure.Persistence.Data.Configurations.BillConfig
{
    public class BillConfig : BaseEntityConfig<Bill>
    {
        public override void Configure(EntityTypeBuilder<Bill> builder)
        {
            builder.Property(t => t.PaidAmount)
               .HasColumnType("decimal(18,2)")
               .IsRequired();

            builder.Property(t => t.Title)
                .IsRequired();

            builder.Property(b => b.Frequency).HasConversion<int>();
        }
    }
}
