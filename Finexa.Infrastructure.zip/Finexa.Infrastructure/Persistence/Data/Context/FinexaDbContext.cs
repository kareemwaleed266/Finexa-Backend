﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Finexa.Domain.Entities.Ai;
using Finexa.Domain.Entities.Financial;
using Finexa.Domain.Entities.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Finexa.Infrastructure.Persistence.Data.Context
{
    public class FinexaDbContext : IdentityDbContext<AppUser, AppRole, Guid>
    {
        public FinexaDbContext(DbContextOptions options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.ApplyConfigurationsFromAssembly(typeof(AssemblyInformation).Assembly);
        }

        // Identity already via base class
        public DbSet<Transaction> Transactions { get; set; }
        public DbSet<Saving> Savings { get; set; }
        public DbSet<Income> Incomes { get; set; }
        public DbSet<IncomeCategory> IncomeCategories { get; set; }
        public DbSet<Expense> Expenses { get; set; }
        public DbSet<ExpenseCategory> ExpenseCategories { get; set; }
        public DbSet<PaymentMethod> PaymentMethods { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Goal> Goals { get; set; }
        public DbSet<Reminder> Reminders { get; set; }
        public DbSet<Notification> Notifications { get; set; }
        public DbSet<SavingPlan> SavingPlans { get; set; }
        public DbSet<Bill> Bills { get; set; }
        public DbSet<UserFinancialSummary> UserFinancialSummaries { get; set; }
        public DbSet<UserBalance> UserBalances { get; set; }
        public DbSet<AiForecastResult> AiForecastResults { get; set; }
        public DbSet<AiInsight> AiInsights { get; set; }
    }
}
