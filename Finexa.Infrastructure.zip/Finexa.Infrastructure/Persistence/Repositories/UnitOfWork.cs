﻿using System.Collections.Concurrent;

namespace Finexa.Infrastructure.Persistence.Repositories
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly FinexaDbContext _context;
        private readonly ConcurrentDictionary<string, object> _repositories;
        public UnitOfWork(FinexaDbContext context)
        {
            _context = context;
            _repositories = new();
        }
        public IGenericRepository<TEntity, TKey> Repository<TEntity, TKey>()
            where TEntity : BaseEntity<TKey>
            where TKey : IEquatable<TKey>
        {
            #region MyRegion
            //var type = typeof(TEntity).Name;
            //if (_repositories.ContainsKey(type))
            //    return (IGenericRepositories<TEntity, TKey>)_repositories[type];

            //var repository = new GenericRepository<TEntity, TKey>(_context);
            //_repositories.Add(type, repository);

            //return repository; 
            #endregion

            return (IGenericRepository<TEntity, TKey>)_repositories.GetOrAdd(typeof(TEntity).Name,
                new GenericRepository<TEntity, TKey>(_context));
        }

        public Task<int> CompleteAsync()
            => _context.SaveChangesAsync();

        public ValueTask DisposeAsync()
            => _context.DisposeAsync();

    }
}
